$ErrorActionPreference = "Stop"
$ToolScript = Join-Path $PSScriptRoot "analytical-lab\run_tool.ps1"
if (-not (Test-Path -LiteralPath $ToolScript)) {
    throw "The Analytical Lab folder is missing. Keep this launcher beside the Analytical Lab folder."
}
& $ToolScript
if ($LASTEXITCODE -ne 0) { throw "The Analytical Lab data tool did not start successfully." }
