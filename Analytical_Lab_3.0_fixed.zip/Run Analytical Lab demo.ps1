$ErrorActionPreference = "Stop"
$DemoScript = Join-Path $PSScriptRoot "analytical-lab\run_demo.ps1"
if (-not (Test-Path -LiteralPath $DemoScript)) {
    throw "The Analytical Lab folder is missing. Keep this launcher beside the Analytical Lab folder."
}
& $DemoScript
if ($LASTEXITCODE -ne 0) { throw "The Analytical Lab demo did not complete successfully." }
