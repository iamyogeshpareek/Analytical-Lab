$ErrorActionPreference = "Stop"
$ProjectDir = $PSScriptRoot
$VenvDir = Join-Path $ProjectDir ".venv"
$VenvPython = Join-Path $ProjectDir ".venv\Scripts\python.exe"

if (Test-Path -LiteralPath $VenvPython) {
    & $VenvPython --version *> $null
    $VenvWorks = ($LASTEXITCODE -eq 0)
} else {
    $VenvWorks = $false
}

if (-not $VenvWorks) {
    if (Test-Path -LiteralPath $VenvDir) {
        $ProjectFullPath = [System.IO.Path]::GetFullPath($ProjectDir)
        $VenvFullPath = [System.IO.Path]::GetFullPath($VenvDir)
        if (-not $VenvFullPath.StartsWith(
            $ProjectFullPath + [System.IO.Path]::DirectorySeparatorChar,
            [System.StringComparison]::OrdinalIgnoreCase
        )) {
            throw "Refusing to remove a Python environment outside the project folder."
        }
        Remove-Item -LiteralPath $VenvDir -Recurse -Force
    }
    $PyLauncher = Get-Command py -ErrorAction SilentlyContinue
    if ($PyLauncher) {
        & $PyLauncher.Source -3 -m venv $VenvDir
    } else {
        $PythonCommand = Get-Command python -ErrorAction SilentlyContinue
        if (-not $PythonCommand) {
            throw "Python 3.9 or newer is required. Install Python, then run this file again."
        }
        & $PythonCommand.Source -m venv $VenvDir
    }
    if ($LASTEXITCODE -ne 0) { throw "Could not create the project's Python environment." }
}

& $VenvPython -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw "Could not prepare pip in the project's Python environment." }
& $VenvPython -m pip install $ProjectDir
if ($LASTEXITCODE -ne 0) { throw "Could not install Analytical Lab and its dependencies." }

$ReportPath = Join-Path $ProjectDir "examples\demo_report.html"
$ReportArgs = @(
    "report",
    "--linearity", (Join-Path $ProjectDir "examples\linearity.csv"),
    "--accuracy", (Join-Path $ProjectDir "examples\accuracy.csv"),
    "--precision", (Join-Path $ProjectDir "examples\precision.csv"),
    "--robustness", (Join-Path $ProjectDir "examples\robustness.csv"),
    "--robustness-factors", "flow_rate,temperature",
    "--title", "DEMO (synthetic data)",
    "--conc-unit", "ug/mL",
    "--r2-min", "0.99",
    "--recovery-min", "98",
    "--recovery-max", "102",
    "--repeatability-rsd-max", "2",
    "--intermediate-rsd-max", "2",
    "--out", $ReportPath
)
& (Join-Path $ProjectDir ".venv\Scripts\analytical-lab.exe") @ReportArgs
if ($LASTEXITCODE -ne 0) { throw "The example report could not be generated." }

Write-Host "Example report created: $ReportPath"
Invoke-Item -LiteralPath $ReportPath
