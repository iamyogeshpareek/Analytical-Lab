# Publication readiness checklist

This reflects the repository as of 2026-10-05 and the current JOSS submission
page. It is a roadmap, not a statement that the package is ready to submit.

## Completed in this working copy

- MIT license retained; tests, a CI workflow, contribution guidance, and citation
  metadata added.
- CSV and Excel table inputs and a descriptive two-setting robustness summary are
  documented.
- Known-answer and regression cross-check tests are present; all tests pass locally.
- Synthetic examples are labelled as demonstrations only.
- A preliminary competitor review is recorded in `NOVELTY_REVIEW.md`.

## Still required before public release

- Verify contributor credit, author affiliation, maintainer details, and the AI-use
  statement.
- Publish the source repository with issues enabled, a meaningful commit history,
  releases, and a CI workflow running on the hosted repository.
- Complete direct searches of PubMed, Google Scholar, GitHub, PyPI, and CRAN; record
  exact query strings, dates, screening decisions, current features, and licenses.
- Assess the substantial overlap with `measure` and other tools. Do not claim novelty
  until there is a specific, evidenced distinction.
- Have an independent analyst review formulas, column mapping, and reports. Compare
  every calculation against independent known results and real, authorized data in a
  private workflow. Do not put private datasets or instrument-brand references in this
  public repository. Never present synthetic data as experimental evidence.
- Include public experimental data only when publication rights and permissions allow.
- Decide the first-release scope. AQbD and full design-of-experiments modules remain
  separate future work and are not part of this package.

## Paper and venue

JOSS currently requires an OSI-approved open-source license, a public source
repository, research application, author contribution, documentation, and tests. Its
current screening requires more than six months of active public development and
evidence of research use; releases, CI, documentation, and iterative development matter.
A new public repository cannot be submitted immediately. Human review, verified
novelty, and demonstrated use are also required before a paper is submission-ready.
Check venue requirements again at submission time.

Elsevier describes SoftwareX as a multidisciplinary, peer-reviewed journal for detailed
articles about research software and its application. The detailed current SoftwareX
author guide returned an access error during this review, so its present article format,
license, code, and review requirements have not been verified here.

ICH Q2(R2) is the primary official guideline reference for validation characteristics.
The software does not set acceptance limits or certify a method as compliant. Use the
applicable official guideline text and qualified scientific review for protocol choices.

## Release hygiene (after the above)

- Confirm package-name availability and metadata, then publish a tagged release.
- Archive the tagged source on Zenodo or another suitable service, obtain its DOI, and
  update citation and availability metadata.
- Recheck installation, tests, sample reports, and Excel input from a clean environment.
