"""Descriptive summaries for two-level robustness experiments.

This module reports observed responses at each tested setting and the relative
high-minus-low effect. It does not fit a factorial model, test significance, or
decide whether a procedure is robust; those conclusions depend on the protocol
and design.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np

from ._util import as_1d_float


@dataclass(frozen=True)
class FactorEffect:
    factor: str
    low_setting: str
    high_setting: str
    n_low: int
    n_high: int
    mean_low: float
    mean_high: float
    sd_low: float
    sd_high: float
    effect: float
    effect_percent_of_grand_mean: float


@dataclass(frozen=True)
class RobustnessResult:
    response_name: str
    effects: Tuple[FactorEffect, ...]


def summarize_robustness(data, factors, response: str = "response") -> RobustnessResult:
    """Summarize numeric two-level factors in a pandas DataFrame.

    Each factor must have exactly two numeric settings with at least two
    observations per setting. Effects are descriptive high-minus-low changes.
    Interactions and design adequacy are not assessed.
    """
    import pandas as pd

    if not isinstance(data, pd.DataFrame):
        raise TypeError("data must be a pandas DataFrame")
    factors = list(factors)
    if not factors:
        raise ValueError("at least one factor column is required")
    needed = [response, *factors]
    missing = [c for c in needed if c not in data.columns]
    if missing:
        raise ValueError(f"missing column(s): {missing}")
    y = as_1d_float(response, data[response].to_numpy())
    out = []
    for factor in factors:
        try:
            settings = np.asarray(data[factor], dtype=float)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"factor {factor!r} must contain numeric low/high settings") from exc
        if not np.all(np.isfinite(settings)):
            raise ValueError(f"factor {factor!r} contains missing or non-finite settings")
        levels = np.unique(settings)
        if levels.size != 2:
            raise ValueError(f"factor {factor!r} must have exactly two tested settings")
        lo, hi = (y[settings == level] for level in levels)
        if lo.size < 2 or hi.size < 2:
            raise ValueError(f"factor {factor!r} needs at least 2 observations per setting")
        ml, mh = float(lo.mean()), float(hi.mean())
        grand = float(y.mean())
        effect = mh - ml
        pct = effect / abs(grand) * 100.0 if grand != 0 else float("nan")
        out.append(FactorEffect(
            factor=str(factor), low_setting=str(levels[0]), high_setting=str(levels[1]),
            n_low=int(lo.size), n_high=int(hi.size), mean_low=ml, mean_high=mh,
            sd_low=float(lo.std(ddof=1)), sd_high=float(hi.std(ddof=1)),
            effect=effect, effect_percent_of_grand_mean=pct,
        ))
    return RobustnessResult(str(response), tuple(out))
