"""Analytical Lab: transparent statistics and reporting for HPLC method validation."""

from ._version import __version__
from .accuracy import AccuracyResult, assess_accuracy, percent_recovery
from .limits import LimitsResult, lod_loq_from_calibration, lod_loq_from_curves, lod_loq_from_sn
from .linearity import LinearityResult, fit_linearity
from .precision import (
    IntermediatePrecisionResult,
    RepeatabilityResult,
    intermediate_precision,
    percent_rsd,
    repeatability,
)
from .replicates import (
    ReplicateCalibration,
    ReplicateSummary,
    accuracy_from_replicates,
    back_calculate,
    fit_replicate_calibration,
    summarize_replicates,
)
from .report import Criteria, build_report, plot_linearity
from .robustness import FactorEffect, RobustnessResult, summarize_robustness

__all__ = [
    "__version__",
    "AccuracyResult",
    "Criteria",
    "IntermediatePrecisionResult",
    "LimitsResult",
    "LinearityResult",
    "RepeatabilityResult",
    "assess_accuracy",
    "build_report",
    "fit_linearity",
    "intermediate_precision",
    "lod_loq_from_calibration",
    "lod_loq_from_sn",
    "percent_recovery",
    "percent_rsd",
    "plot_linearity",
    "repeatability",
    "ReplicateCalibration",
    "ReplicateSummary",
    "accuracy_from_replicates",
    "back_calculate",
    "fit_replicate_calibration",
    "lod_loq_from_curves",
    "summarize_replicates",
    "FactorEffect",
    "RobustnessResult",
    "summarize_robustness",
]
