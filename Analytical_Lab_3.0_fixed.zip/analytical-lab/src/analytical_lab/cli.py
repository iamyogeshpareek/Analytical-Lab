"""Command-line interface: ``analytical-lab report ...``.

Expected CSV columns
--------------------
linearity : conc, response   or   conc, area1, area2, ... (replicate injections)
accuracy  : level, added, found
precision : value            (repeatability)
            value, group     (repeatability + intermediate precision)
robustness: response and numeric two-level factor columns
"""

from __future__ import annotations

import argparse
import sys
from typing import Optional, Sequence

import pandas as pd

from .accuracy import assess_accuracy
from .limits import lod_loq_from_calibration, lod_loq_from_curves
from .linearity import fit_linearity
from .precision import intermediate_precision, repeatability
from .replicates import fit_replicate_calibration
from .report import Criteria, build_report
from .robustness import summarize_robustness


def _read(path: str, required: Sequence[str]) -> pd.DataFrame:
    suffix = path.lower().rsplit(".", 1)[-1] if "." in path else ""
    if suffix == "csv":
        df = pd.read_csv(path)
    elif suffix in {"xlsx", "xls"}:
        df = pd.read_excel(path)
    else:
        raise ValueError(f"{path}: input must be CSV, XLSX, or XLS")
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"{path}: missing required column(s) {missing}; found {list(df.columns)}")
    return df


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="analytical-lab", description="HPLC method validation statistics and report.")
    sub = p.add_subparsers(dest="command", required=True)
    r = sub.add_parser("report", help="compute statistics from CSV files and write an HTML report")
    r.add_argument("--linearity", help="CSV: conc,response  or  conc,area1,area2,... (replicates)")
    r.add_argument("--accuracy", help="CSV with columns level,added,found")
    r.add_argument("--precision", help="CSV/XLSX with column value and optional group")
    r.add_argument("--robustness", help="CSV/XLSX with a response and two-level factor columns")
    r.add_argument("--robustness-factors", help="Comma-separated factor column names")
    r.add_argument("--robustness-response", default="response", help="Response column (default: response)")
    r.add_argument("--out", default="validation_report.html")
    r.add_argument("--title", default="HPLC method validation report")
    r.add_argument("--conc-unit", default="")
    r.add_argument("--response-unit", default="")
    r.add_argument("--confidence", type=float, default=0.95)
    r.add_argument("--sigma-source", choices=["residual_sd", "intercept_se"], default="residual_sd")
    r.add_argument("--r2-min", type=float)
    r.add_argument("--recovery-min", type=float)
    r.add_argument("--recovery-max", type=float)
    r.add_argument("--repeatability-rsd-max", type=float)
    r.add_argument("--intermediate-rsd-max", type=float)
    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = _build_parser().parse_args(argv)
    if not (args.linearity or args.accuracy or args.precision or args.robustness):
        print("error: provide at least one analysis input", file=sys.stderr)
        return 2
    try:
        fit = limits = acc = rep = ip = cal = robust = None
        if args.linearity:
            d = _read(args.linearity, ["conc"])
            area_cols = [c for c in d.columns if str(c).lower().startswith("area")]
            if "response" in d.columns:
                fit = fit_linearity(d["conc"], d["response"], args.confidence)
                limits = [lod_loq_from_calibration(fit, args.sigma_source)]
            elif len(area_cols) >= 2:
                cal = fit_replicate_calibration(d["conc"], d[area_cols].to_numpy(), args.confidence)
                fit = cal.fit_all
                limits = [lod_loq_from_calibration(fit, "residual_sd"),
                          lod_loq_from_calibration(fit, "intercept_se"),
                          lod_loq_from_curves(cal.fit_each)]
            else:
                raise ValueError("linearity CSV needs a 'response' column or at least two 'area*' columns")
        if args.accuracy:
            d = _read(args.accuracy, ["level", "added", "found"])
            acc = assess_accuracy(d["level"], d["added"], d["found"], args.confidence)
        if args.precision:
            d = _read(args.precision, ["value"])
            if "group" in d.columns:
                ip = intermediate_precision(d["value"], d["group"].tolist())
            else:
                rep = repeatability(d["value"])
        if args.robustness:
            if not args.robustness_factors:
                raise ValueError("--robustness requires --robustness-factors")
            factors = [s.strip() for s in args.robustness_factors.split(",") if s.strip()]
            d = _read(args.robustness, [args.robustness_response, *factors])
            robust = summarize_robustness(d, factors, args.robustness_response)
        criteria = Criteria(
            r_squared_min=args.r2_min,
            recovery_min=args.recovery_min,
            recovery_max=args.recovery_max,
            repeatability_rsd_max=args.repeatability_rsd_max,
            intermediate_rsd_max=args.intermediate_rsd_max,
        )
        text = build_report(args.title, fit, limits, acc, rep, ip, criteria,
                            args.conc_unit, args.response_unit, calibration=cal,
                            robustness=robust)
    except (ValueError, OSError, pd.errors.ParserError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    with open(args.out, "w", encoding="utf-8") as fh:
        fh.write(text)
    print(f"Report written to {args.out}")
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
