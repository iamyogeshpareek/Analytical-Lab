"""Simple desktop file picker for generating reports from user data."""

from __future__ import annotations

import contextlib
import io
import webbrowser
from pathlib import Path

from .cli import main as cli_main


def main() -> int:
    """Open a Tkinter window for selecting data tables and generating a report."""
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk
    except ImportError as exc:  # pragma: no cover - platform dependent
        raise SystemExit(
            "Tkinter is not available in this Python installation. Install a standard "
            "Python distribution with Tcl/Tk support."
        ) from exc

    root = tk.Tk()
    root.title("Analytical Lab — Create a validation report")
    root.geometry("790x790")
    root.minsize(690, 650)

    outer = ttk.Frame(root, padding=18)
    outer.pack(fill="both", expand=True)
    ttk.Label(outer, text="Create a report from your data", font=("Segoe UI", 16, "bold")).pack(anchor="w")
    ttk.Label(
        outer,
        text="Choose one or more CSV or Excel tables. Your files stay on this computer.",
        wraplength=730,
    ).pack(anchor="w", pady=(4, 12))

    table = ttk.LabelFrame(outer, text="Data tables", padding=10)
    table.pack(fill="x", pady=5)
    files: dict[str, tk.StringVar] = {}
    rows = [
        ("Calibration / linearity", "conc,response  OR  conc,Area 1,Area 2,..."),
        ("Accuracy / recovery", "level,added,found"),
        ("Precision", "value  (optional group column)"),
        ("Robustness", "response and numeric two-setting factor columns"),
    ]
    filetypes = [("CSV and Excel tables", "*.csv *.xlsx *.xls"), ("All files", "*.*")]
    for index, (key, hint) in enumerate(rows):
        var = tk.StringVar()
        files[key] = var
        line = ttk.Frame(table)
        line.grid(row=index * 2, column=0, sticky="ew", pady=(4, 0))
        ttk.Label(line, text=key, width=25).pack(side="left")
        ttk.Entry(line, textvariable=var).pack(side="left", fill="x", expand=True, padx=5)

        def browse(target=var):
            selected = filedialog.askopenfilename(
                parent=root, title="Choose a data table", filetypes=filetypes
            )
            if selected:
                target.set(selected)

        ttk.Button(line, text="Browse…", command=browse).pack(side="left")
        ttk.Label(table, text=hint, foreground="#555").grid(
            row=index * 2 + 1, column=0, sticky="w", padx=(25, 0), pady=(0, 4)
        )
    table.columnconfigure(0, weight=1)

    settings = ttk.LabelFrame(outer, text="Report settings", padding=10)
    settings.pack(fill="x", pady=5)
    values: dict[str, tk.StringVar] = {}

    def add_field(row: int, label: str, key: str, default: str = "", width: int = 22):
        ttk.Label(settings, text=label).grid(row=row, column=0, sticky="w", padx=4, pady=3)
        var = tk.StringVar(value=default)
        values[key] = var
        ttk.Entry(settings, textvariable=var, width=width).grid(
            row=row, column=1, sticky="ew", padx=4, pady=3
        )

    add_field(0, "Report title", "title", "Analytical procedure validation report", 50)
    add_field(1, "Concentration unit", "conc_unit", "")
    add_field(2, "Response unit", "response_unit", "")
    add_field(3, "Confidence level (0–1)", "confidence", "0.95")
    add_field(4, "Minimum R² (optional)", "r2_min")
    add_field(5, "Recovery minimum (%) (optional)", "recovery_min")
    add_field(6, "Recovery maximum (%) (optional)", "recovery_max")
    add_field(7, "Maximum repeatability %RSD (optional)", "repeatability_rsd_max")
    add_field(8, "Maximum intermediate %RSD (optional)", "intermediate_rsd_max")
    add_field(9, "Robustness factor columns (comma-separated)", "robustness_factors", "", 40)
    settings.columnconfigure(1, weight=1)

    report = tk.StringVar(value=str(Path.cwd() / "validation_report.html"))
    outrow = ttk.Frame(outer)
    outrow.pack(fill="x", pady=8)
    ttk.Label(outrow, text="Save report as", width=25).pack(side="left")
    ttk.Entry(outrow, textvariable=report).pack(side="left", fill="x", expand=True, padx=5)

    def choose_output():
        selected = filedialog.asksaveasfilename(
            parent=root,
            title="Save HTML report",
            defaultextension=".html",
            initialfile="validation_report.html",
            filetypes=[("HTML report", "*.html")],
        )
        if selected:
            report.set(selected)

    ttk.Button(outrow, text="Browse…", command=choose_output).pack(side="left")

    def generate():
        args = ["report"]
        selected_args = [
            ("Calibration / linearity", "--linearity"),
            ("Accuracy / recovery", "--accuracy"),
            ("Precision", "--precision"),
            ("Robustness", "--robustness"),
        ]
        for key, flag in selected_args:
            path = files[key].get().strip()
            if path:
                args.extend([flag, path])
        if len(args) == 1:
            messagebox.showerror("Select data", "Choose at least one data table.", parent=root)
            return
        factor_text = values["robustness_factors"].get().strip()
        if files["Robustness"].get().strip() and not factor_text:
            messagebox.showerror(
                "Robustness factors",
                "Enter the robustness factor column names, separated by commas.",
                parent=root,
            )
            return
        if factor_text:
            args.extend(["--robustness-factors", factor_text])
        for key, flag in (("title", "--title"), ("conc_unit", "--conc-unit"),
                          ("response_unit", "--response-unit"), ("confidence", "--confidence"),
                          ("r2_min", "--r2-min"), ("recovery_min", "--recovery-min"),
                          ("recovery_max", "--recovery-max"),
                          ("repeatability_rsd_max", "--repeatability-rsd-max"),
                          ("intermediate_rsd_max", "--intermediate-rsd-max")):
            value = values[key].get().strip()
            if value:
                args.extend([flag, value])
        output = report.get().strip()
        if not output:
            messagebox.showerror("Report location", "Choose where to save the report.", parent=root)
            return
        args.extend(["--out", output])
        captured_out, captured_err = io.StringIO(), io.StringIO()
        try:
            with contextlib.redirect_stdout(captured_out), contextlib.redirect_stderr(captured_err):
                code = cli_main(args)
        except SystemExit as exc:
            detail = captured_err.getvalue().strip()
            messagebox.showerror(
                "Check report settings",
                detail or f"The report command stopped with code {exc.code}.",
                parent=root,
            )
            return
        except Exception as exc:  # Surface file/parser failures to the user.
            messagebox.showerror("Could not create report", str(exc), parent=root)
            return
        if code != 0:
            messagebox.showerror(
                "Could not create report",
                captured_err.getvalue().strip() or "Check the selected files and column names.",
                parent=root,
            )
            return
        try:
            webbrowser.open(Path(output).resolve().as_uri())
        except Exception:
            pass
        messagebox.showinfo("Report ready", f"Report saved to:\n{output}", parent=root)

    ttk.Label(
        outer,
        text="Use headers shown beside each file selector. The report summarizes the selected tables; it does not process chromatogram trace files.",
        wraplength=730,
        foreground="#555",
    ).pack(anchor="w", pady=(2, 8))
    ttk.Button(outer, text="Generate report", command=generate).pack(anchor="e", pady=4)
    root.mainloop()
    return 0


if __name__ == "__main__":  # pragma: no cover - application entry point
    raise SystemExit(main())
