"""Precision: repeatability and intermediate precision.

Intermediate precision is estimated with a one-way random-effects ANOVA in which
the grouping factor is the varied condition (e.g. day or analyst):

    s_r^2  = MS_within
    s_b^2  = max(0, (MS_between - MS_within) / n0)
    s_IP^2 = s_r^2 + s_b^2

with n0 = (N - sum(n_i^2) / N) / (k - 1), which also handles unbalanced designs.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ._util import as_1d_float


@dataclass(frozen=True)
class RepeatabilityResult:
    n: int
    mean: float
    sd: float
    rsd: float


@dataclass(frozen=True)
class IntermediatePrecisionResult:
    n_groups: int
    n_total: int
    grand_mean: float
    s_repeatability: float
    s_between: float
    s_intermediate: float
    rsd_repeatability: float
    rsd_intermediate: float
    ms_within: float
    ms_between: float


def percent_rsd(values) -> float:
    x = as_1d_float("values", values)
    if x.size < 2:
        raise ValueError("At least 2 values are required for %RSD")
    mean = float(x.mean())
    if mean == 0.0:
        return float("nan")
    return float(x.std(ddof=1)) / mean * 100.0


def repeatability(values) -> RepeatabilityResult:
    x = as_1d_float("values", values)
    if x.size < 2:
        raise ValueError("At least 2 replicates are required")
    return RepeatabilityResult(
        n=int(x.size),
        mean=float(x.mean()),
        sd=float(x.std(ddof=1)),
        rsd=percent_rsd(x),
    )


def intermediate_precision(values, groups) -> IntermediatePrecisionResult:
    x = as_1d_float("values", values)
    labels = list(groups)
    if len(labels) != x.size:
        raise ValueError("values and groups must have the same length")
    if any(lab is None or (isinstance(lab, (float, np.floating)) and np.isnan(lab))
           for lab in labels):
        raise ValueError("groups contains missing labels")

    order: dict = {}
    for lab in labels:
        order.setdefault(lab, len(order))
    idx = np.array([order[lab] for lab in labels])
    k = len(order)
    big_n = x.size
    if k < 2:
        raise ValueError("At least 2 groups are required for intermediate precision")
    if big_n <= k:
        raise ValueError("Need more observations than groups (replicates within groups)")

    n_i = np.bincount(idx, minlength=k).astype(float)
    mean_i = np.bincount(idx, weights=x, minlength=k) / n_i
    grand = float(x.mean())

    ss_within = float(np.sum((x - mean_i[idx]) ** 2))
    ss_between = float(np.sum(n_i * (mean_i - grand) ** 2))
    ms_within = ss_within / (big_n - k)
    ms_between = ss_between / (k - 1)
    n0 = (big_n - float(np.sum(n_i**2)) / big_n) / (k - 1)
    var_between = max(0.0, (ms_between - ms_within) / n0)

    s_r = float(np.sqrt(ms_within))
    s_b = float(np.sqrt(var_between))
    s_ip = float(np.sqrt(ms_within + var_between))
    if grand != 0.0:
        rsd_r = s_r / grand * 100.0
        rsd_ip = s_ip / grand * 100.0
    else:
        rsd_r = rsd_ip = float("nan")

    return IntermediatePrecisionResult(
        n_groups=k,
        n_total=int(big_n),
        grand_mean=grand,
        s_repeatability=s_r,
        s_between=s_b,
        s_intermediate=s_ip,
        rsd_repeatability=rsd_r,
        rsd_intermediate=rsd_ip,
        ms_within=ms_within,
        ms_between=ms_between,
    )
