"""Replicate (e.g. triplicate-injection) handling.

Chromatographic validation data are usually acquired as n replicate injections per
level (n = 3 is typical). This module provides:

* per-level mean, sample SD (n - 1) and %RSD,
* back-calculation of concentration from each individual replicate response,
* calibration fits on (i) all injections, (ii) the level means (what a spreadsheet
  trendline on a mean-area chart gives) and (iii) each replicate series separately,
* recovery computed per replicate (mean, SD, %RSD over replicates and levels).

For a balanced design (same number of replicates at every level) the slope and
intercept of the all-injection fit equal those of the level-mean fit; r^2 does not,
because averaging removes the within-level scatter. State which one you quote.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np

from ._util import as_1d_float
from .accuracy import AccuracyResult, assess_accuracy
from .linearity import LinearityResult, fit_linearity


def _as_2d(name: str, values) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    if arr.ndim != 2:
        raise ValueError(f"{name} must be two-dimensional (levels x replicates)")
    if arr.shape[1] < 2:
        raise ValueError(f"{name} needs at least 2 replicates per level")
    if arr.shape[0] < 1:
        raise ValueError(f"{name} is empty")
    if not np.all(np.isfinite(arr)):
        raise ValueError(f"{name} contains NaN or infinite values")
    return arr


@dataclass(frozen=True)
class ReplicateSummary:
    levels: np.ndarray
    n_replicates: int
    values: np.ndarray
    mean: np.ndarray
    sd: np.ndarray
    rsd: np.ndarray


def summarize_replicates(levels, areas) -> ReplicateSummary:
    """Mean, sample SD (n - 1) and %RSD of the replicates at every level."""
    lv = as_1d_float("levels", levels)
    a = _as_2d("areas", areas)
    if a.shape[0] != lv.size:
        raise ValueError("levels and areas must have the same number of rows")
    mean = a.mean(axis=1)
    sd = a.std(axis=1, ddof=1)
    with np.errstate(divide="ignore", invalid="ignore"):
        rsd = np.where(mean != 0.0, sd / mean * 100.0, np.nan)
    return ReplicateSummary(lv, int(a.shape[1]), a, mean, sd, rsd)


def back_calculate(response, slope: float, intercept: float) -> np.ndarray:
    """Concentration from response: (response - intercept) / slope."""
    if slope == 0.0:
        raise ValueError("slope is zero; cannot back-calculate")
    return (np.asarray(response, dtype=float) - intercept) / slope


@dataclass(frozen=True)
class ReplicateCalibration:
    summary: ReplicateSummary
    fit_all: LinearityResult
    fit_mean: LinearityResult
    fit_each: Tuple[LinearityResult, ...]


def fit_replicate_calibration(conc, areas, confidence: float = 0.95) -> ReplicateCalibration:
    """Calibration fits for replicate data (rows = levels, columns = replicates)."""
    x = as_1d_float("conc", conc)
    a = _as_2d("areas", areas)
    if a.shape[0] != x.size:
        raise ValueError("conc and areas must have the same number of rows")
    k = a.shape[1]
    summary = summarize_replicates(x, a)
    fit_all = fit_linearity(np.repeat(x, k), a.ravel(), confidence)
    fit_mean = fit_linearity(x, summary.mean, confidence)
    fit_each = tuple(fit_linearity(x, a[:, j], confidence) for j in range(k))
    return ReplicateCalibration(summary, fit_all, fit_mean, fit_each)


def accuracy_from_replicates(
    nominal, areas, slope: float, intercept: float, confidence: float = 0.95
) -> AccuracyResult:
    """Recovery of each individual replicate against its nominal concentration."""
    nom = as_1d_float("nominal", nominal)
    a = _as_2d("areas", areas)
    if a.shape[0] != nom.size:
        raise ValueError("nominal and areas must have the same number of rows")
    k = a.shape[1]
    found = back_calculate(a, slope, intercept)
    rep_nom = np.repeat(nom, k)
    return assess_accuracy(rep_nom, rep_nom, found.ravel(), confidence)
