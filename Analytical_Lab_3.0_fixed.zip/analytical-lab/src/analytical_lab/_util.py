"""Small input-validation helpers shared by all modules."""

from __future__ import annotations

import numpy as np


def as_1d_float(name: str, values) -> np.ndarray:
    """Convert ``values`` to a finite, non-empty 1-D float array or raise ValueError."""
    arr = np.asarray(values, dtype=float)
    if arr.ndim != 1:
        raise ValueError(f"{name} must be one-dimensional")
    if arr.size == 0:
        raise ValueError(f"{name} is empty")
    if not np.all(np.isfinite(arr)):
        raise ValueError(f"{name} contains NaN or infinite values")
    return arr


def check_confidence(confidence: float) -> float:
    if not (0.0 < confidence < 1.0):
        raise ValueError("confidence must be strictly between 0 and 1")
    return float(confidence)
