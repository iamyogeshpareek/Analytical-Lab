"""Detection and quantitation limits.

Three approaches are implemented:

1. Calibration-curve approach: LOD = 3.3 * sigma / S and LOQ = 10 * sigma / S,
   where S is the slope of the calibration line and sigma is an estimate of the
   response standard deviation. Here sigma may be the residual standard deviation
   of the regression ("residual_sd") or the standard error of the intercept
   ("intercept_se"). Which estimate is appropriate is a methodological decision
   that must be justified in the validation protocol.

2. Signal-to-noise approach: the concentration giving the target S/N ratio
   (3 and 10 by default) is obtained by linear scaling from one injection of a
   known low concentration. The convention used to measure noise (peak-to-peak
   vs. RMS, region of baseline) changes the result and must be stated by the user.

3. Replicate-curve approach: sigma is the sample SD of the y-intercepts of k separate
   calibration curves and S is their mean slope (LOD = 3.3*sigma/S, LOQ = 10*sigma/S).
   This treats the k curves as independent; if they are replicate injections of one
   dilution series they are not independent, so justify the choice in the protocol.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np

from ._util import check_confidence  # noqa: F401  (re-exported for symmetry)
from .linearity import LinearityResult

LOD_FACTOR = 3.3
LOQ_FACTOR = 10.0


@dataclass(frozen=True)
class LimitsResult:
    method: str
    lod: float
    loq: float
    detail: str


def lod_loq_from_calibration(
    fit: LinearityResult, sigma_source: str = "residual_sd"
) -> LimitsResult:
    """LOD/LOQ from a fitted calibration line (see module docstring)."""
    if sigma_source == "residual_sd":
        sigma = fit.residual_sd
    elif sigma_source == "intercept_se":
        sigma = fit.intercept_se
    else:
        raise ValueError("sigma_source must be 'residual_sd' or 'intercept_se'")
    slope = abs(fit.slope)
    return LimitsResult(
        method="calibration curve",
        lod=LOD_FACTOR * sigma / slope,
        loq=LOQ_FACTOR * sigma / slope,
        detail=f"sigma = {sigma:.6g} ({sigma_source}); |slope| = {slope:.6g}",
    )


def lod_loq_from_sn(
    concentration: float,
    signal: float,
    noise: float,
    lod_sn: float = 3.0,
    loq_sn: float = 10.0,
) -> LimitsResult:
    """LOD/LOQ by scaling a measured S/N to the target S/N ratios.

    ``concentration`` is the concentration of the low-level injection, ``signal``
    its peak height and ``noise`` the baseline noise in the same response units.
    """
    for name, value in (("concentration", concentration), ("signal", signal), ("noise", noise)):
        if not value > 0:
            raise ValueError(f"{name} must be positive")
    if not lod_sn > 0 or not loq_sn > 0:
        raise ValueError("target signal-to-noise ratios must be positive")
    if loq_sn < lod_sn:
        raise ValueError("loq_sn must be greater than or equal to lod_sn")
    sn_measured = signal / noise
    return LimitsResult(
        method="signal-to-noise",
        lod=concentration * lod_sn / sn_measured,
        loq=concentration * loq_sn / sn_measured,
        detail=f"measured S/N = {sn_measured:.6g}; targets {lod_sn:g} (LOD) and {loq_sn:g} (LOQ)",
    )


def lod_loq_from_curves(fits: Sequence[LinearityResult]) -> LimitsResult:
    """LOD/LOQ from k >= 2 separate calibration curves (see module docstring, approach 3)."""
    fits = list(fits)
    if len(fits) < 2:
        raise ValueError("At least 2 calibration curves are required")
    intercepts = np.array([f.intercept for f in fits], dtype=float)
    slope = abs(float(np.mean([f.slope for f in fits])))
    if slope == 0.0:
        raise ValueError("Mean slope is zero")
    sigma = float(np.std(intercepts, ddof=1))
    return LimitsResult(
        method=f"SD of intercepts / mean slope ({len(fits)} curves)",
        lod=LOD_FACTOR * sigma / slope,
        loq=LOQ_FACTOR * sigma / slope,
        detail=f"SD(intercepts) = {sigma:.6g}; mean slope = {slope:.6g}",
    )
