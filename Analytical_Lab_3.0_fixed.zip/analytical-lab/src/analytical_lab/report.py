"""Self-contained HTML validation report (plots embedded as PNG)."""

from __future__ import annotations

import base64
import html
import io
import platform
from dataclasses import dataclass
from datetime import datetime, timezone
import math
from typing import Optional, Sequence, Union

import matplotlib
import numpy as np
import scipy
from matplotlib.figure import Figure

from ._version import __version__
from .accuracy import AccuracyResult
from .limits import LimitsResult
from .linearity import LinearityResult
from .precision import IntermediatePrecisionResult, RepeatabilityResult
from .replicates import ReplicateCalibration
from .robustness import RobustnessResult


@dataclass(frozen=True)
class Criteria:
    """User-defined acceptance criteria. No defaults are assumed: a criterion that is
    left as None is simply not evaluated. Criteria must come from your validation
    protocol / the guideline you follow, not from this software."""

    r_squared_min: Optional[float] = None
    recovery_min: Optional[float] = None
    recovery_max: Optional[float] = None
    repeatability_rsd_max: Optional[float] = None
    intermediate_rsd_max: Optional[float] = None

    def __post_init__(self):
        for name in ("r_squared_min", "recovery_min", "recovery_max",
                     "repeatability_rsd_max", "intermediate_rsd_max"):
            value = getattr(self, name)
            if value is not None and not math.isfinite(value):
                raise ValueError(f"{name} must be finite")
        if self.r_squared_min is not None and not 0 <= self.r_squared_min <= 1:
            raise ValueError("r_squared_min must be between 0 and 1")
        if self.recovery_min is not None and self.recovery_max is not None \
                and self.recovery_min > self.recovery_max:
            raise ValueError("recovery_min cannot exceed recovery_max")
        for name in ("repeatability_rsd_max", "intermediate_rsd_max"):
            value = getattr(self, name)
            if value is not None and value < 0:
                raise ValueError(f"{name} cannot be negative")


def _fmt(x: float, digits: int = 5) -> str:
    if x is None or (isinstance(x, float) and not np.isfinite(x)):
        return "n/a"
    return f"{x:.{digits}g}"


def _table(headers, rows) -> str:
    head = "".join(f"<th>{html.escape(str(h))}</th>" for h in headers)
    body = "".join(
        "<tr>" + "".join(f"<td>{html.escape(str(c))}</td>" for c in row) + "</tr>" for row in rows
    )
    return f"<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>"


def _verdict(ok: Optional[bool]) -> str:
    if ok is None:
        return "not evaluated"
    return "meets criterion" if ok else "DOES NOT meet criterion"


def _png_base64(fig: Figure) -> str:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150, bbox_inches="tight")
    return base64.b64encode(buf.getvalue()).decode("ascii")


def plot_linearity(fit: LinearityResult, conc_unit: str = "", response_unit: str = "") -> Figure:
    fig = Figure(figsize=(9, 3.6))
    ax1, ax2 = fig.subplots(1, 2)
    xs = np.linspace(float(fit.conc.min()), float(fit.conc.max()), 100)
    ax1.scatter(fit.conc, fit.response, zorder=3)
    ax1.plot(xs, fit.intercept + fit.slope * xs)
    ax1.set_xlabel(f"Concentration {conc_unit}".strip())
    ax1.set_ylabel(f"Response {response_unit}".strip())
    ax1.set_title("Calibration curve")
    ax2.axhline(0.0, linewidth=1)
    ax2.scatter(fit.conc, fit.residuals, zorder=3)
    ax2.set_xlabel(f"Concentration {conc_unit}".strip())
    ax2.set_ylabel("Residual")
    ax2.set_title("Residuals")
    fig.tight_layout()
    return fig


def build_report(
    title: str = "HPLC method validation report",
    linearity: Optional[LinearityResult] = None,
    limits: Union[LimitsResult, Sequence[LimitsResult], None] = None,
    accuracy: Optional[AccuracyResult] = None,
    repeatability: Optional[RepeatabilityResult] = None,
    intermediate: Optional[IntermediatePrecisionResult] = None,
    criteria: Optional[Criteria] = None,
    conc_unit: str = "",
    response_unit: str = "",
    calibration: Optional[ReplicateCalibration] = None,
    robustness: Optional[RobustnessResult] = None,
) -> str:
    crit = criteria or Criteria()
    parts = []
    supplied = [("Minimum r squared", crit.r_squared_min),
                ("Minimum recovery (%)", crit.recovery_min),
                ("Maximum recovery (%)", crit.recovery_max),
                ("Maximum repeatability RSD (%)", crit.repeatability_rsd_max),
                ("Maximum intermediate precision RSD (%)", crit.intermediate_rsd_max)]
    supplied = [(name, _fmt(value)) for name, value in supplied if value is not None]
    if supplied:
        parts.append("<h2>User-supplied acceptance criteria</h2>" + _table(["Criterion", "Value"], supplied))
    if limits is None:
        limit_list = []
    elif isinstance(limits, LimitsResult):
        limit_list = [limits]
    else:
        limit_list = list(limits)
    if calibration is not None and linearity is None:
        linearity = calibration.fit_all

    if linearity is not None:
        f = linearity
        ok = None if crit.r_squared_min is None else bool(f.r_squared >= crit.r_squared_min)
        rows = [
            ("Points / distinct levels", f"{f.n} / {f.n_levels}"),
            ("Slope", f"{_fmt(f.slope)}  ({f.confidence:.0%} CI {_fmt(f.slope_ci[0])} to {_fmt(f.slope_ci[1])})"),
            ("Intercept", f"{_fmt(f.intercept)}  ({f.confidence:.0%} CI {_fmt(f.intercept_ci[0])} to {_fmt(f.intercept_ci[1])})"),
            ("Intercept CI includes zero", "yes" if f.intercept_ci_includes_zero else "no"),
            ("r", _fmt(f.r, 6)),
            ("r squared", _fmt(f.r_squared, 6)),
            ("Residual SD", _fmt(f.residual_sd)),
        ]
        if crit.r_squared_min is not None:
            rows.append((f"r squared >= {crit.r_squared_min:g}", _verdict(ok)))
        extra = ""
        if calibration is not None:
            s = calibration.summary
            rows.append(("r squared on level means (spreadsheet-trendline style)",
                         _fmt(calibration.fit_mean.r_squared, 6)))
            rep_headers = ["Level"] + [f"Area {j + 1}" for j in range(s.n_replicates)] + ["Mean", "SD", "%RSD"]
            rep_rows = [
                tuple([_fmt(lv)] + [_fmt(v, 8) for v in s.values[i]]
                      + [_fmt(s.mean[i], 8), _fmt(s.sd[i], 5), _fmt(s.rsd[i], 4)])
                for i, lv in enumerate(s.levels)
            ]
            ser_rows = [
                (f"Area {j + 1} vs conc", _fmt(ft.slope), _fmt(ft.intercept), _fmt(ft.r_squared, 6))
                for j, ft in enumerate(calibration.fit_each)
            ]
            extra = (
                "<h3>Replicate summary per level</h3>" + _table(rep_headers, rep_rows)
                + "<h3>Separate curve per replicate series</h3>"
                + _table(["Series", "Slope", "Intercept", "r squared"], ser_rows)
            )
        img = _png_base64(plot_linearity(f, conc_unit, response_unit))
        bc_rows = [
            (_fmt(x), _fmt(y), _fmt(b), _fmt(d, 4), _fmt(r))
            for x, y, b, d, r in zip(
                f.conc, f.response, f.back_calculated, f.percent_deviation, f.residuals
            )
        ]
        parts.append(
            "<h2>Linearity</h2>"
            + _table(["Parameter", "Value"], rows)
            + f'<img alt="Calibration curve and residual plot" src="data:image/png;base64,{img}">'
            + "<h3>Back-calculated concentrations</h3>"
            + _table(["Nominal", "Response", "Back-calculated", "Deviation (%)", "Residual"], bc_rows)
            + extra
        )

    if limit_list:
        parts.append(
            "<h2>Detection and quantitation limits</h2>"
            + _table(
                ["Approach", "LOD", "LOQ", "Detail"],
                [(lm.method, f"{_fmt(lm.lod)} {conc_unit}".strip(),
                  f"{_fmt(lm.loq)} {conc_unit}".strip(), lm.detail) for lm in limit_list],
            )
        )

    if accuracy is not None:
        rows = []
        for lv in accuracy.levels:
            has_recovery_criterion = crit.recovery_min is not None or crit.recovery_max is not None
            ok = None if not has_recovery_criterion else bool(
                (crit.recovery_min is None or lv.mean_recovery >= crit.recovery_min)
                and (crit.recovery_max is None or lv.mean_recovery <= crit.recovery_max)
            )
            rows.append((_fmt(lv.level), lv.n, _fmt(lv.mean_recovery, 4), _fmt(lv.sd, 4),
                         _fmt(lv.rsd, 4), f"{_fmt(lv.ci[0], 4)} to {_fmt(lv.ci[1], 4)}", _verdict(ok)))
        rows.append(("All", accuracy.n, _fmt(accuracy.overall_mean, 4), _fmt(accuracy.overall_sd, 4),
                     _fmt(accuracy.overall_rsd, 4),
                     f"{_fmt(accuracy.overall_ci[0], 4)} to {_fmt(accuracy.overall_ci[1], 4)}", ""))
        parts.append(
            "<h2>Accuracy (percent recovery)</h2>"
            + _table(["Level", "n", "Mean recovery (%)", "SD", "RSD (%)",
                      f"{accuracy.confidence:.0%} CI of mean", "Criterion"], rows)
        )

    if repeatability is not None:
        ok = None if crit.repeatability_rsd_max is None else bool(repeatability.rsd <= crit.repeatability_rsd_max)
        parts.append(
            "<h2>Precision: repeatability</h2>"
            + _table(["n", "Mean", "SD", "RSD (%)", "Criterion"],
                     [(repeatability.n, _fmt(repeatability.mean), _fmt(repeatability.sd),
                       _fmt(repeatability.rsd, 4), _verdict(ok))])
        )

    if intermediate is not None:
        ip = intermediate
        ok_r = None if crit.repeatability_rsd_max is None else bool(ip.rsd_repeatability <= crit.repeatability_rsd_max)
        ok_ip = None if crit.intermediate_rsd_max is None else bool(ip.rsd_intermediate <= crit.intermediate_rsd_max)
        parts.append(
            "<h2>Precision: repeatability and intermediate precision</h2>"
            + _table(
                ["Groups", "N", "Grand mean", "s (repeatability)", "RSD repeatability (%)",
                 "s (between groups)", "s (intermediate)", "RSD intermediate (%)", "Criteria"],
                [(ip.n_groups, ip.n_total, _fmt(ip.grand_mean), _fmt(ip.s_repeatability),
                  _fmt(ip.rsd_repeatability, 4), _fmt(ip.s_between), _fmt(ip.s_intermediate),
                  _fmt(ip.rsd_intermediate, 4),
                  f"repeatability: {_verdict(ok_r)}; intermediate: {_verdict(ok_ip)}")],
            )
        )

    if robustness is not None:
        rows = [
            (e.factor, e.low_setting, e.n_low, _fmt(e.mean_low), _fmt(e.sd_low),
             e.high_setting, e.n_high, _fmt(e.mean_high), _fmt(e.sd_high),
             _fmt(e.effect), f"{_fmt(e.effect_percent_of_grand_mean, 4)}%")
            for e in robustness.effects
        ]
        parts.append(
            "<h2>Robustness: descriptive two-setting effects</h2>"
            + _table(["Factor", "Low setting", "n", "Mean", "SD", "High setting", "n",
                      "Mean", "SD", "High − low", "% of grand mean"], rows)
            + "<p>Descriptive effects only; this summary does not assess interactions, "
              "design adequacy, statistical significance, or acceptance criteria.</p>"
        )

    if not parts:
        raise ValueError("Nothing to report: provide at least one result object")

    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    env = (f"Analytical Lab {__version__}; Python {platform.python_version()}; "
           f"NumPy {np.__version__}; SciPy {scipy.__version__}; Matplotlib {matplotlib.__version__}")
    style = (
        "body{font-family:system-ui,Arial,sans-serif;max-width:960px;margin:2rem auto;padding:0 1rem;color:#1a1a1a}"
        "table{border-collapse:collapse;margin:1rem 0;width:100%}"
        "th,td{border:1px solid #bbb;padding:.35rem .6rem;text-align:left;font-size:.9rem}"
        "th{background:#f0f0f0}img{max-width:100%}footer{margin-top:2rem;font-size:.8rem;color:#555}"
    )
    return (
        "<!doctype html><html lang='en'><head><meta charset='utf-8'>"
        f"<title>{html.escape(title)}</title><style>{style}</style></head><body>"
        f"<h1>{html.escape(title)}</h1>"
        + "".join(parts)
        + "<footer><p>Acceptance criteria shown above are user-supplied; this software does not "
        "assume regulatory limits. Results should be reviewed by a qualified analyst.</p>"
        f"<p>Generated {stamp}. {html.escape(env)}.</p></footer></body></html>"
    )
