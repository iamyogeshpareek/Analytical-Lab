"""Linearity assessment by ordinary (unweighted) least squares.

All quantities are computed from closed-form textbook expressions so that every
number in a report can be reproduced by hand:

    slope b      = Sxy / Sxx
    intercept a  = ybar - b * xbar
    residual SD  = sqrt(SS_res / (n - 2))
    SE(b)        = s / sqrt(Sxx)
    SE(a)        = s * sqrt(1/n + xbar^2 / Sxx)
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass
from typing import Tuple

import numpy as np
from scipy import stats

from ._util import as_1d_float, check_confidence


@dataclass(frozen=True)
class LinearityResult:
    n: int
    n_levels: int
    slope: float
    intercept: float
    r: float
    r_squared: float
    residual_sd: float
    slope_se: float
    intercept_se: float
    slope_ci: Tuple[float, float]
    intercept_ci: Tuple[float, float]
    confidence: float
    intercept_ci_includes_zero: bool
    conc: np.ndarray
    response: np.ndarray
    residuals: np.ndarray
    back_calculated: np.ndarray
    percent_deviation: np.ndarray


def fit_linearity(conc, response, confidence: float = 0.95) -> LinearityResult:
    """Fit ``response = intercept + slope * conc`` by unweighted least squares.

    Parameters
    ----------
    conc, response : array-like
        Calibration concentrations and detector responses (same length, >= 3 points).
    confidence : float
        Confidence level for the slope and intercept intervals (default 0.95).
    """
    confidence = check_confidence(confidence)
    x = as_1d_float("conc", conc)
    y = as_1d_float("response", response)
    if x.size != y.size:
        raise ValueError("conc and response must have the same length")
    n = x.size
    if n < 3:
        raise ValueError("At least 3 points are required to fit and assess a line")

    n_levels = int(np.unique(x).size)
    if n_levels < 5:
        warnings.warn(
            f"Only {n_levels} distinct concentration level(s); a minimum of five levels "
            "is commonly recommended for linearity - check the guideline you follow.",
            UserWarning,
            stacklevel=2,
        )

    xbar = x.mean()
    ybar = y.mean()
    sxx = float(np.sum((x - xbar) ** 2))
    if sxx == 0.0:
        raise ValueError("All concentrations are identical; cannot fit a line")
    sxy = float(np.sum((x - xbar) * (y - ybar)))
    syy = float(np.sum((y - ybar) ** 2))

    slope = sxy / sxx
    intercept = float(ybar - slope * xbar)
    fitted = intercept + slope * x
    residuals = y - fitted
    ss_res = float(np.sum(residuals**2))
    dof = n - 2
    s = float(np.sqrt(ss_res / dof))

    slope_se = s / np.sqrt(sxx)
    intercept_se = s * np.sqrt(1.0 / n + xbar**2 / sxx)
    tcrit = float(stats.t.ppf(1.0 - (1.0 - confidence) / 2.0, dof))
    slope_ci = (slope - tcrit * slope_se, slope + tcrit * slope_se)
    intercept_ci = (intercept - tcrit * intercept_se, intercept + tcrit * intercept_se)

    if syy == 0.0:
        r = float("nan")
    else:
        r = sxy / np.sqrt(sxx * syy)
    r_squared = float(r * r) if np.isfinite(r) else float("nan")

    if slope == 0.0:
        raise ValueError("Fitted slope is zero; response does not depend on concentration")
    back = (y - intercept) / slope
    with np.errstate(divide="ignore", invalid="ignore"):
        pct_dev = np.where(x != 0.0, (back - x) / x * 100.0, np.nan)

    return LinearityResult(
        n=int(n),
        n_levels=n_levels,
        slope=float(slope),
        intercept=intercept,
        r=float(r),
        r_squared=r_squared,
        residual_sd=s,
        slope_se=float(slope_se),
        intercept_se=float(intercept_se),
        slope_ci=(float(slope_ci[0]), float(slope_ci[1])),
        intercept_ci=(float(intercept_ci[0]), float(intercept_ci[1])),
        confidence=confidence,
        intercept_ci_includes_zero=bool(intercept_ci[0] <= 0.0 <= intercept_ci[1]),
        conc=x,
        response=y,
        residuals=residuals,
        back_calculated=back,
        percent_deviation=pct_dev,
    )
