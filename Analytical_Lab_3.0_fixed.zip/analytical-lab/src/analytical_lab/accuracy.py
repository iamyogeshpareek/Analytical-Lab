"""Accuracy expressed as percent recovery of spiked (added) analyte."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np
from scipy import stats

from ._util import as_1d_float, check_confidence


@dataclass(frozen=True)
class RecoveryLevel:
    level: float
    n: int
    mean_recovery: float
    sd: float
    rsd: float
    ci: Tuple[float, float]


@dataclass(frozen=True)
class AccuracyResult:
    levels: Tuple[RecoveryLevel, ...]
    n: int
    overall_mean: float
    overall_sd: float
    overall_rsd: float
    overall_ci: Tuple[float, float]
    confidence: float
    recoveries: np.ndarray


def percent_recovery(added, found) -> np.ndarray:
    """Return 100 * found / added element-wise."""
    a = as_1d_float("added", added)
    f = as_1d_float("found", found)
    if a.size != f.size:
        raise ValueError("added and found must have the same length")
    if np.any(a <= 0):
        raise ValueError("added amounts must be positive")
    return 100.0 * f / a


def _mean_sd_ci(values: np.ndarray, confidence: float):
    n = values.size
    mean = float(values.mean())
    if n < 2:
        return mean, float("nan"), float("nan"), (float("nan"), float("nan"))
    sd = float(values.std(ddof=1))
    rsd = sd / mean * 100.0 if mean != 0 else float("nan")
    half = float(stats.t.ppf(1.0 - (1.0 - confidence) / 2.0, n - 1)) * sd / np.sqrt(n)
    return mean, sd, rsd, (mean - half, mean + half)


def assess_accuracy(levels, added, found, confidence: float = 0.95) -> AccuracyResult:
    """Summarise recovery per spiking level and overall.

    ``levels`` labels each determination (e.g. 80, 100, 120 for percent of target).
    """
    confidence = check_confidence(confidence)
    lv = as_1d_float("levels", levels)
    rec = percent_recovery(added, found)
    if lv.size != rec.size:
        raise ValueError("levels, added and found must have the same length")

    out = []
    for level in np.unique(lv):
        r = rec[lv == level]
        mean, sd, rsd, ci = _mean_sd_ci(r, confidence)
        out.append(RecoveryLevel(float(level), int(r.size), mean, sd, rsd, ci))

    mean, sd, rsd, ci = _mean_sd_ci(rec, confidence)
    return AccuracyResult(
        levels=tuple(out),
        n=int(rec.size),
        overall_mean=mean,
        overall_sd=sd,
        overall_rsd=rsd,
        overall_ci=ci,
        confidence=confidence,
        recoveries=rec,
    )
