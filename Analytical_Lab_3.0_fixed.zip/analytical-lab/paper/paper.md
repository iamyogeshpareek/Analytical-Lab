---
title: "Analytical Lab: transparent statistics and reporting for chromatographic analytical procedure validation"
tags:
  - Python
  - chromatography
  - analytical chemistry
  - method validation
authors:
  - name: "Yogesh Kumar Pareek"
    orcid: "0009-0005-5662-030X"
    affiliation: 1
affiliations:
  - name: "Department of Pharmaceutical Sciences and Technology, Maharaja Ranjit Singh Punjab Technical University, Bathinda, India"
    index: 1
date: "2026-10-05"
bibliography: paper.bib
---

<!-- Draft only. Author affiliation, claims, references, and all AI-assisted work need
human review. This is not a submission-ready JOSS paper. -->

# Summary

`Analytical Lab` is a Python library and command-line application for calculating and reporting selected quantitative characteristics of chromatographic analytical procedures. It accepts already-integrated numeric results in CSV or Excel tables: calibration concentration and response, replicate responses, recovery measurements, precision observations and groups, and numeric factor settings for a limited descriptive robustness summary. It does not read instrument-specific binary files or integrate chromatograms. It produces numerical results and a self-contained HTML report with tables, calibration and residual plots, user-supplied criteria, and software-version metadata.

The current implementation includes unweighted least-squares calibration, residual and back-calculation summaries, two calibration-curve estimates and a signal-to-noise estimate for detection and quantitation limits, recovery summaries, repeatability, one-way random-effects intermediate precision, replicate calibration summaries, and descriptive two-setting factor effects. It has no default acceptance criteria. The selection of statistical approach, experimental design, and acceptance limits remains with the analyst and applicable protocol.

# Statement of need

Quantitative validation studies use data from several experiments and commonly report calibration behavior, detection and quantitation limits, recovery, and precision. Calculation workflows that are distributed across spreadsheets or scripts can be difficult to review consistently, reproduce, and include in version-controlled analyses. `Analytical Lab` provides a small Python API and command-line workflow for a defined set of these calculations, with explicit formulae, synthetic examples, automated tests, and a single-file report. It is aimed at researchers and analytical scientists who already have numerical peak-area or response tables and want a transparent, scriptable calculation layer.

This package is not a chromatogram processor, a validated regulated system, or a certificate that an analytical procedure is fit for purpose. It does not currently cover specificity, reportable-range assessment, weighted regression, lack-of-fit, outlier procedures, or factorial robustness and interaction analysis. The included robustness function reports observed marginal means and high-minus-low effects only; it does not determine whether the method is robust.

# State of the field

Open-source software already covers neighboring and overlapping problems. `hplc-py` processes chromatographic traces and quantifies peaks [@chure2024]. The R package `measure` describes calibration, detection and quantitation limits, accuracy, precision, and linearity functions, among other analytical-measurement tools [@measure]. The `veRification` application addresses clinical-laboratory imprecision and trueness using Bayesian and frequentist analyses [@wilkes2023]. Earlier work described automated processing of data for chromatographic assay validation [@haky1985]. These precedents mean that neither computerized chromatographic validation nor the individual statistics in this package can be claimed as novel by themselves.

A preliminary, non-systematic comparison is documented in `NOVELTY_REVIEW.md`. The precise comparative contribution, current implementation status of related packages, and the value of a Python API plus an auditable HTML report require further study before any novelty claim. The public development history and demonstrated research use required by the intended venue also remain to be established.

# Software design

The package uses small result data classes and explicit formulae for the principal estimators. This makes calculation pathways inspectable and supports hand-computable known-answer tests. Ordinary least squares is the only calibration fit currently supported; weighted fitting is not silently selected. Acceptance limits are optional user inputs, not package defaults. Reports show the criteria used and include a reminder that results need qualified review. CSV and Excel readers consume tabular data after peak integration; the analysis layer is independent of any specific acquisition system.

For replicate calibrations, the library calculates fits on all injections, level means, and each replicate series. The report distinguishes these fits because averaging affects R-squared even where balanced designs yield the same slope and intercept. For intermediate precision, it uses one-way random-effects ANOVA variance components and supports unbalanced group sizes. LOD/LOQ functions expose the sigma source or method in the returned result so the user can document the protocol choice.

# Validation of the software

The repository contains tests with hand-computable linear-regression and precision examples, comparisons with SciPy and NumPy regression implementations, invalid-input checks, and command-line/report tests. A local run of the suite completed with 65 passing tests after the addition of Excel and robustness CLI coverage. These tests check software behavior on synthetic and known-answer inputs; they do not establish that any particular analytical procedure is valid or that the calculations match a user's laboratory records.

Before publication, an independent analyst should review the equations and data mapping, and a documented reference analysis should compare each reported quantity with independent calculations on authorized experimental data. No experimental result or user-specific dataset is included here. Synthetic example tables are for demonstration only.

# Research impact statement

The package is not yet publicly released, and no external research use is claimed. Evidence of actual research use and sustained public development must be added before a software-paper submission is considered.

# AI usage disclosure

The initial code, tests, documentation, example generator, and manuscript skeleton in the supplied source archive were attributed to Claude Sonnet 5.5. Subsequent code changes, tests, documentation, and this draft were assisted by OpenAI Codex (GPT-6) on 2026-10-05. The author must review, edit, and verify every assisted contribution, confirm the tool/model details, make the core scientific and design decisions, and take responsibility for the final software and text. This statement must be corrected if any detail is inaccurate.

# Acknowledgements

TODO: add acknowledgements and funding information, if applicable.

# References

