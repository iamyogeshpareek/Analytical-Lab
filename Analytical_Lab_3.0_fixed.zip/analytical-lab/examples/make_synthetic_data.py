"""Generate SYNTHETIC demonstration data (NOT real measurements).

The numbers produced here are simulated with a fixed random seed purely to show the
input file formats and the report layout. They must never be reported as experimental
results. Replace them with real chromatographic data for any actual validation.
"""

from pathlib import Path

import numpy as np

rng = np.random.default_rng(2026)
out = Path(__file__).parent

# Linearity: 6 levels, arbitrary units, ~1 % proportional noise
conc = np.array([10, 20, 40, 60, 80, 100], dtype=float)
resp = 25.0 * conc + 5.0 + rng.normal(0, 0.01 * 25.0 * conc)
(out / "linearity.csv").write_text(
    "conc,response\n" + "\n".join(f"{c:g},{r:.2f}" for c, r in zip(conc, resp)) + "\n"
)

# Accuracy: 3 spiking levels x 3 replicates
rows = []
for level in (80, 100, 120):
    for _ in range(3):
        rows.append((level, level, level * (1 + rng.normal(0, 0.008))))
(out / "accuracy.csv").write_text(
    "level,added,found\n" + "\n".join(f"{a},{b},{c:.3f}" for a, b, c in rows) + "\n"
)

# Precision: 3 days x 6 replicates around 100 % label claim, with a small day effect
rows = []
for day, shift in zip(("day1", "day2", "day3"), rng.normal(0, 0.4, 3)):
    for v in 100 + shift + rng.normal(0, 0.5, 6):
        rows.append((f"{v:.2f}", day))
(out / "precision.csv").write_text(
    "value,group\n" + "\n".join(f"{v},{g}" for v, g in rows) + "\n"
)
# Triplicate linearity: 6 levels x 3 injections, ~1.5 % proportional noise
rows = []
for c in conc:
    reps = 25.0 * c + 5.0 + rng.normal(0, 0.015 * 25.0 * c, 3)
    rows.append((c, *reps))
(out / "linearity_triplicate.csv").write_text(
    "conc,Area 1,Area 2,Area 3\n" + "\n".join(f"{c:g},{a:.1f},{b:.1f},{d:.1f}" for c, a, b, d in rows) + "\n"
)
print("Synthetic example files written to", out)
