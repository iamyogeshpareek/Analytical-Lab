$ErrorActionPreference = "Stop"
$ProjectDir = $PSScriptRoot
$VenvDir = Join-Path $ProjectDir ".venv"
$VenvPython = Join-Path $VenvDir "Scripts\python.exe"

if (Test-Path -LiteralPath $VenvPython) {
    & $VenvPython --version *> $null
    $VenvWorks = ($LASTEXITCODE -eq 0)
} else {
    $VenvWorks = $false
}

if (-not $VenvWorks) {
    if (Test-Path -LiteralPath $VenvDir) {
        $ProjectFullPath = [System.IO.Path]::GetFullPath($ProjectDir)
        $VenvFullPath = [System.IO.Path]::GetFullPath($VenvDir)
        if (-not $VenvFullPath.StartsWith(
            $ProjectFullPath + [System.IO.Path]::DirectorySeparatorChar,
            [System.StringComparison]::OrdinalIgnoreCase
        )) { throw "Refusing to remove a Python environment outside the project folder." }
        Remove-Item -LiteralPath $VenvDir -Recurse -Force
    }
    $PyLauncher = Get-Command py -ErrorAction SilentlyContinue
    if ($PyLauncher) {
        & $PyLauncher.Source -3 -m venv $VenvDir
    } else {
        $PythonCommand = Get-Command python -ErrorAction SilentlyContinue
        if (-not $PythonCommand) { throw "Python 3.9 or newer is required. Install Python, then run this file again." }
        & $PythonCommand.Source -m venv $VenvDir
    }
    if ($LASTEXITCODE -ne 0) { throw "Could not create the project's Python environment." }
}

& $VenvPython -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw "Could not prepare pip in the project's Python environment." }
& $VenvPython -m pip install $ProjectDir
if ($LASTEXITCODE -ne 0) { throw "Could not install Analytical Lab and its dependencies." }
& (Join-Path $VenvDir "Scripts\analytical-lab-gui.exe")
if ($LASTEXITCODE -ne 0) { throw "The data-entry window could not be started. Check that your Python installation includes Tkinter." }
