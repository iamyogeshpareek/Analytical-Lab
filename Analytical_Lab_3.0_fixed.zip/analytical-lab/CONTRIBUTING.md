# Contributing

Bug reports, questions, and proposed changes are welcome. Please include a small,
shareable example that reproduces a problem. Do not include confidential laboratory
data in public issues; replace it with synthetic or suitably anonymized data.

For code changes:

1. Create an isolated change and explain the scientific or usability reason.
2. Add known-answer tests for new calculations and input-validation tests for edge cases.
3. Run `pytest` and `python -m build` before proposing the change.
4. Update the documentation and changelog when behavior or user-facing features change.

All reported results require review by a qualified analyst. A passing test suite is
evidence about the implementation, not evidence that a method is fit for purpose.
