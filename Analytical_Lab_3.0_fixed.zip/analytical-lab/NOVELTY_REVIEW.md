# Preliminary landscape review

Reviewed 2026-10-05. This is a starting point for Phase 0, not a systematic review.
The following targeted web-search queries were run on this date: “Python HPLC method
validation software analytical procedure regression recovery precision”; “site:pypi.org
HPLC validation linearity precision accuracy method validation”; “PubMed HPLC method
validation software package analytical validation”; “site:github.com analytical
procedure validation Python HPLC LOD LOQ precision”; and “ICH Q2(R2) Q14 chromatographic
analytical procedure validation robustness”. Search-engine indexing is not a substitute
for direct database searches. Exact queries, filters, dates, and complete result screening
in PubMed, Google Scholar, GitHub, PyPI, and CRAN remain necessary before publication.

| Tool or source | What it appears to cover | Relation to this package | License / availability observed |
|---|---|---|---|
| `measure` (R) | Analytical measurement workflows; repository lists weighted calibration, LOD/LOQ, repeatability, intermediate precision, accuracy, linearity with lack-of-fit, criteria, and other analyses | Strong functional overlap; a Python implementation of common calculations alone is not an established novelty claim | GitHub repository reports MIT; assess the current source, release, documentation, and actual implementation before claiming comparative strengths |
| `hplc-py` (Python) | Chromatogram trace processing, peak detection/fitting, and quantification | Adjacent input-processing layer; not the same scope as validation summaries from concentration/response/replicate tables | GPL-3.0; public source and JOSS article |
| `veRification` (R/Shiny) | Clinical laboratory imprecision, trueness, method comparison, and diagnostic performance | Related validation/verification software, but a different clinical-laboratory focus and statistical framework | Article describes an open-source R package; package license and present maintenance state need direct confirmation |
| Haky & Domonkos (1985) | Automated chromatographic assay-validation calculations and reports | Historical precedent showing computerized chromatographic validation is not itself new | Bibliographic record is public; current software availability and license not established |
| BioProcess Tools Method Validation Calculator | Website advertises LOD/LOQ, linearity, recovery, precision, and parameter presets | Direct feature overlap at calculator/workflow level; distinguishability needs a hands-on feature comparison | Website available; source code and license not established |
| Analyse-it Method Validation | Commercial statistical method-validation software with linearity, precision, and detection limits among its features | Commercial comparator; shared analytical scope is not novel | Proprietary product; vendor page available |
| PyPI / Google Scholar / CRAN | Initial targeted searches found no dependable completeness evidence | Absence from search results is not evidence of absence | Search protocols and results are not yet archived systematically |

## Current conclusion

The broad claim “open-source software for HPLC method-validation calculations” is
not yet supported as a novel contribution. At least one current R package reports
substantial overlap, and commercial and web calculators also cover several of the
same characteristics. A defensible paper would need a carefully evidenced distinction
(for example, a clearly defined Python API and auditable report workflow) plus a
comparison showing why that distinction matters. It must not claim a regulatory
endorsement or that the package itself validates an analytical procedure.

## Primary references

- ICH Q2(R2), official guideline: <https://database.ich.org/sites/default/files/ICH_Q2%28R2%29_Guideline_2023_1130.pdf>
- `measure`: <https://github.com/JamesHWade/measure>
- `hplc-py`: <https://github.com/cremerlab/hplc-py>
- Haky & Domonkos, *Automated data processing for chromatographic assay method validations* (1985): <https://pubmed.ncbi.nlm.nih.gov/4044763/>
- Wilkes, *veRification: an R Shiny application for laboratory method verification and validation* (2023): <https://pubmed.ncbi.nlm.nih.gov/37053372/>
- BioProcess Tools calculator: <https://bioprocesstools.com/>
- Analyse-it Method Validation: <https://analyse-it.com/products/method-validation>
