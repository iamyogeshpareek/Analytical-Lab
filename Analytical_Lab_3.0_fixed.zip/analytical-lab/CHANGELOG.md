# Changelog

## 0.3.0

- Added intermediate-precision and replicate-calibration workflows.
- Added CSV command-line reporting and embedded HTML plots.
- Added descriptive two-setting robustness summaries and Excel workbook input.
- Added validated user-supplied criteria reporting and missing-group checks.
- Expanded known-answer, edge-case, Excel, and command-line test coverage.

This changelog describes the working copy. Version 0.3.0 is not yet a published release.

## 0.2.0

- Added intermediate-precision and replicate-calibration workflows.
- Added CSV command-line reporting and embedded HTML plots.
- Added known-answer and regression cross-check tests.
