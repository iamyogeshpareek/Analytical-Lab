# Analytical Lab Python toolkit

This folder contains the optional Python API, command-line interface, and desktop data-entry tool for Analytical Lab. The standalone browser app is `../Analytical Lab.html`; open that file for the quickest start.

## Windows setup

From the archive root, run `Open Analytical Lab data tool.ps1`. It creates a local Python environment and installs dependencies. Python 3.9 or newer and internet access are needed for initial setup.

For the synthetic sample report, run `Run Analytical Lab demo.ps1` from the archive root. Example tables contain synthetic data only.

After installing, see command help with `analytical-lab report --help`. In Python, import the package as `analytical_lab`.

## Scope

The Python toolkit calculates selected calibration, accuracy, precision, detection/quantitation limit, and robustness summaries from numeric tables. It does not read instrument-specific binary files or establish regulatory compliance. Review its documented assumptions and verify results independently against the approved protocol and applicable guidance.

## License

MIT License. See [LICENSE](LICENSE).
