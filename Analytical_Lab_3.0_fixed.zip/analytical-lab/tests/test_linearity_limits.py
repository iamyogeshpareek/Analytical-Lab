import math
import warnings

import numpy as np
import pytest
from scipy import stats

from analytical_lab import fit_linearity, lod_loq_from_calibration, lod_loq_from_sn

# Hand-computable dataset: Sxx = 10, Sxy = 19.9, slope = 1.99, intercept = 0.05,
# SS_res = 0.107, residual SD = sqrt(0.107 / 3).
X = [1, 2, 3, 4, 5]
Y = [2.1, 3.9, 6.2, 7.8, 10.1]


def test_known_answer_by_hand():
    fit = fit_linearity(X, Y)
    assert fit.slope == pytest.approx(1.99, abs=1e-12)
    assert fit.intercept == pytest.approx(0.05, abs=1e-12)
    assert fit.residual_sd == pytest.approx(math.sqrt(0.107 / 3), rel=1e-12)
    assert fit.r_squared == pytest.approx(19.9**2 / (10 * 39.708), rel=1e-10)


def test_matches_scipy_linregress_on_random_data():
    rng = np.random.default_rng(1)
    x = np.linspace(1, 10, 8)
    y = 3.2 * x + 0.7 + rng.normal(0, 0.3, x.size)
    fit = fit_linearity(x, y)
    ref = stats.linregress(x, y)
    assert fit.slope == pytest.approx(ref.slope, rel=1e-10)
    assert fit.intercept == pytest.approx(ref.intercept, rel=1e-10)
    assert fit.r == pytest.approx(ref.rvalue, rel=1e-10)
    assert fit.slope_se == pytest.approx(ref.stderr, rel=1e-10)
    assert fit.intercept_se == pytest.approx(ref.intercept_stderr, rel=1e-10)


def test_matches_numpy_polyfit():
    rng = np.random.default_rng(2)
    x = np.array([5, 10, 20, 40, 80, 160.0])
    y = 120.0 * x + 15 + rng.normal(0, 20, x.size)
    fit = fit_linearity(x, y)
    slope, intercept = np.polyfit(x, y, 1)
    assert fit.slope == pytest.approx(slope, rel=1e-10)
    assert fit.intercept == pytest.approx(intercept, rel=1e-8)


def test_confidence_interval_contains_true_values_for_clean_data():
    x = np.arange(1, 9, dtype=float)
    y = 2.0 * x + 1.0 + np.array([0.01, -0.02, 0.015, -0.01, 0.02, -0.015, 0.005, -0.005])
    fit = fit_linearity(x, y)
    assert fit.slope_ci[0] < 2.0 < fit.slope_ci[1]
    assert fit.intercept_ci[0] < 1.0 < fit.intercept_ci[1]
    assert not fit.intercept_ci_includes_zero


def test_perfect_line():
    fit = fit_linearity([1, 2, 3, 4, 5], [3, 5, 7, 9, 11])
    assert fit.r_squared == pytest.approx(1.0)
    assert fit.residual_sd == pytest.approx(0.0, abs=1e-12)
    assert np.allclose(fit.percent_deviation, 0.0, atol=1e-9)


def test_back_calculation():
    fit = fit_linearity(X, Y)
    assert np.allclose(fit.back_calculated, (np.array(Y) - 0.05) / 1.99)


def test_warns_with_fewer_than_five_levels():
    with pytest.warns(UserWarning, match="distinct concentration"):
        fit_linearity([1, 2, 3, 4], [2, 4.1, 6, 8.1])


def test_no_warning_with_five_levels():
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        fit_linearity(X, Y)


@pytest.mark.filterwarnings("ignore:Only .* distinct concentration")
@pytest.mark.parametrize(
    "x,y",
    [
        ([1, 2], [1, 2]),
        ([1, 1, 1, 1, 1], [1, 2, 3, 4, 5]),
        ([1, 2, 3], [1, 2]),
        ([1, 2, np.nan, 4, 5], [1, 2, 3, 4, 5]),
        ([1, 2, 3, 4, 5], [4, 4, 4, 4, 4]),
    ],
)
def test_invalid_inputs_raise(x, y):
    with pytest.raises(ValueError):
        fit_linearity(x, y)


def test_invalid_confidence():
    with pytest.raises(ValueError):
        fit_linearity(X, Y, confidence=1.5)


def test_lod_loq_calibration_formulae():
    fit = fit_linearity(X, Y)
    lim = lod_loq_from_calibration(fit)
    assert lim.lod == pytest.approx(3.3 * fit.residual_sd / 1.99, rel=1e-12)
    assert lim.loq == pytest.approx(10.0 * fit.residual_sd / 1.99, rel=1e-12)
    assert lim.loq / lim.lod == pytest.approx(10.0 / 3.3)


def test_lod_loq_intercept_se_option_and_bad_option():
    fit = fit_linearity(X, Y)
    lim = lod_loq_from_calibration(fit, "intercept_se")
    assert lim.lod == pytest.approx(3.3 * fit.intercept_se / 1.99, rel=1e-12)
    with pytest.raises(ValueError):
        lod_loq_from_calibration(fit, "nonsense")


def test_lod_loq_uses_absolute_slope():
    fit = fit_linearity([1, 2, 3, 4, 5], [-2.1, -3.9, -6.2, -7.8, -10.1])
    assert lod_loq_from_calibration(fit).lod > 0


def test_lod_loq_signal_to_noise():
    lim = lod_loq_from_sn(concentration=0.5, signal=60.0, noise=2.0)  # S/N = 30
    assert lim.lod == pytest.approx(0.05)
    assert lim.loq == pytest.approx(1.0 / 6.0)
    with pytest.raises(ValueError):
        lod_loq_from_sn(0.5, 60.0, 0.0)
    with pytest.raises(ValueError, match="greater than or equal"):
        lod_loq_from_sn(0.5, 60.0, 2.0, lod_sn=10, loq_sn=3)
