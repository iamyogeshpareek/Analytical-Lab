import pytest

from analytical_lab import (
    Criteria,
    assess_accuracy,
    build_report,
    fit_linearity,
    intermediate_precision,
    lod_loq_from_calibration,
    repeatability,
)
from analytical_lab.cli import main

X = [1, 2, 3, 4, 5]
Y = [2.1, 3.9, 6.2, 7.8, 10.1]


def test_build_report_contains_expected_sections_and_embedded_plot():
    fit = fit_linearity(X, Y)
    acc = assess_accuracy([80, 80, 100, 100], [80, 80, 100, 100], [79.2, 80.8, 101.0, 99.0])
    ip = intermediate_precision([10, 11, 12, 20, 21, 22], list("AAABBB"))
    html = build_report(
        linearity=fit,
        limits=lod_loq_from_calibration(fit),
        accuracy=acc,
        intermediate=ip,
        criteria=Criteria(r_squared_min=0.99, recovery_min=98.0, recovery_max=102.0),
    )
    for text in ("Linearity", "Detection and quantitation limits", "Accuracy", "intermediate",
                 "data:image/png;base64,", "meets criterion"):
        assert text in html


def test_report_does_not_invent_criteria():
    fit = fit_linearity(X, Y)
    html = build_report(linearity=fit)
    # With no criteria supplied, no pass/fail verdict may appear anywhere.
    assert "meets criterion" not in html
    assert "DOES NOT meet" not in html


def test_report_flags_failed_criterion():
    fit = fit_linearity(X, Y)
    html = build_report(linearity=fit, criteria=Criteria(r_squared_min=0.99999))
    assert "DOES NOT meet criterion" in html


def test_report_evaluates_one_sided_recovery_criterion_and_shows_value():
    accuracy = assess_accuracy([100, 100], [100, 100], [99, 101])
    html = build_report(accuracy=accuracy, criteria=Criteria(recovery_min=99.5))
    assert "Minimum recovery (%)" in html and "99.5" in html
    assert "meets criterion" in html


def test_report_escapes_title():
    fit = fit_linearity(X, Y)
    assert "<script>" not in build_report(title="<script>x</script>", linearity=fit)


def test_report_requires_content():
    with pytest.raises(ValueError):
        build_report()


def test_criteria_reject_impossible_or_reversed_limits():
    with pytest.raises(ValueError):
        Criteria(r_squared_min=1.1)
    with pytest.raises(ValueError):
        Criteria(recovery_min=102, recovery_max=98)


def test_repeatability_section():
    html = build_report(repeatability=repeatability([100.0, 100.5, 99.5, 100.2, 99.8, 100.0]),
                        criteria=Criteria(repeatability_rsd_max=2.0))
    assert "repeatability" in html and "meets criterion" in html


def test_cli_end_to_end(tmp_path):
    lin = tmp_path / "lin.csv"
    lin.write_text("conc,response\n" + "\n".join(f"{x},{y}" for x, y in zip(X, Y)))
    acc = tmp_path / "acc.csv"
    acc.write_text("level,added,found\n80,80,79.2\n80,80,80.8\n100,100,101\n100,100,99\n")
    prec = tmp_path / "prec.csv"
    prec.write_text("value,group\n10,A\n11,A\n12,A\n20,B\n21,B\n22,B\n")
    out = tmp_path / "r.html"
    code = main(["report", "--linearity", str(lin), "--accuracy", str(acc),
                 "--precision", str(prec), "--out", str(out), "--r2-min", "0.99"])
    assert code == 0
    assert "Linearity" in out.read_text(encoding="utf-8")


def test_cli_missing_column_returns_error(tmp_path, capsys):
    bad = tmp_path / "bad.csv"
    bad.write_text("x,y\n1,2\n")
    assert main(["report", "--linearity", str(bad), "--out", str(tmp_path / "o.html")]) == 2
    assert "missing required column" in capsys.readouterr().err


def test_cli_requires_an_input(capsys):
    assert main(["report"]) == 2


def test_cli_robustness_summary(tmp_path):
    data = tmp_path / "robustness.csv"
    data.write_text(
        "flow,response\n1,9\n1,11\n2,12\n2,14\n",
        encoding="utf-8",
    )
    out = tmp_path / "robustness.html"
    assert main(["report", "--robustness", str(data), "--robustness-factors", "flow",
                 "--out", str(out)]) == 0
    report = out.read_text(encoding="utf-8")
    assert "Robustness: descriptive two-setting effects" in report
    assert "interactions" in report


def test_cli_reads_excel_input(tmp_path):
    import pandas as pd

    data = tmp_path / "precision.xlsx"
    pd.DataFrame({"value": [10, 11, 12]}).to_excel(data, index=False)
    out = tmp_path / "precision.html"
    assert main(["report", "--precision", str(data), "--out", str(out)]) == 0
    assert "Precision: repeatability" in out.read_text(encoding="utf-8")
