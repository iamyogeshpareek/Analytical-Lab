import math

import numpy as np
import pytest

from analytical_lab import (
    accuracy_from_replicates,
    back_calculate,
    build_report,
    fit_replicate_calibration,
    lod_loq_from_curves,
    summarize_replicates,
)
from analytical_lab.cli import main

LEVELS = [1, 2, 3, 4, 5]
# Means 10..50, every triplicate has SD exactly 1 (values m-1, m, m+1).
AREAS = [[9, 10, 11], [19, 20, 21], [29, 30, 31], [39, 40, 41], [49, 50, 51]]


def test_summary_known_answer():
    s = summarize_replicates(LEVELS, AREAS)
    assert s.n_replicates == 3
    assert np.allclose(s.mean, [10, 20, 30, 40, 50])
    assert np.allclose(s.sd, 1.0)  # sample SD (n - 1)
    assert np.allclose(s.rsd, [10.0, 5.0, 100 / 30, 2.5, 2.0])


def test_summary_zero_mean_gives_nan_rsd():
    s = summarize_replicates([1], [[-1.0, 0.0, 1.0]])
    assert math.isnan(s.rsd[0])


def test_balanced_design_same_slope_intercept_different_r2():
    cal = fit_replicate_calibration(LEVELS, AREAS)
    assert cal.fit_all.slope == pytest.approx(cal.fit_mean.slope, rel=1e-12)
    assert cal.fit_all.intercept == pytest.approx(cal.fit_mean.intercept, abs=1e-10)
    assert cal.fit_mean.r_squared == pytest.approx(1.0)
    # SS_res = 10, SS_tot = 3 * 1000 + 10
    assert cal.fit_all.r_squared == pytest.approx(1.0 - 10.0 / 3010.0, rel=1e-12)
    assert cal.fit_all.r_squared < cal.fit_mean.r_squared


def test_each_series_fit():
    cal = fit_replicate_calibration(LEVELS, AREAS)
    assert len(cal.fit_each) == 3
    assert [round(f.intercept, 9) for f in cal.fit_each] == [-1.0, 0.0, 1.0]
    assert all(f.slope == pytest.approx(10.0) for f in cal.fit_each)


def test_lod_loq_from_curves_known_answer():
    cal = fit_replicate_calibration(LEVELS, AREAS)
    lim = lod_loq_from_curves(cal.fit_each)
    # SD of intercepts (-1, 0, 1) = 1; mean slope = 10
    assert lim.lod == pytest.approx(3.3 * 1.0 / 10.0)
    assert lim.loq == pytest.approx(10.0 * 1.0 / 10.0)


def test_lod_loq_from_curves_needs_two_curves():
    cal = fit_replicate_calibration(LEVELS, AREAS)
    with pytest.raises(ValueError):
        lod_loq_from_curves(cal.fit_each[:1])


def test_back_calculate():
    assert np.allclose(back_calculate([40, 50], slope=10.0, intercept=0.0), [4.0, 5.0])
    with pytest.raises(ValueError):
        back_calculate([1.0], 0.0, 0.0)


def test_accuracy_from_replicates_known_answer():
    acc = accuracy_from_replicates(
        [4, 5, 6], [[40, 40, 40], [50, 51, 49], [60, 60, 60]], slope=10.0, intercept=0.0
    )
    assert acc.n == 9
    assert acc.overall_mean == pytest.approx(100.0)
    assert acc.overall_sd == pytest.approx(1.0)  # (2^2 + 2^2) / 8 = 1
    lvl5 = [lv for lv in acc.levels if lv.level == 5.0][0]
    assert lvl5.mean_recovery == pytest.approx(100.0)
    assert lvl5.sd == pytest.approx(2.0)


@pytest.mark.parametrize(
    "levels,areas",
    [
        ([1, 2, 3], [[1, 2], [2, 3]]),                 # row mismatch
        ([1, 2], [[1], [2]]),                          # single replicate
        ([1, 2], [1, 2]),                              # 1-D
        ([1, 2], [[1, np.nan], [2, 3]]),               # NaN
    ],
)
def test_invalid_replicate_inputs(levels, areas):
    with pytest.raises(ValueError):
        summarize_replicates(levels, areas)


def test_report_with_calibration_shows_replicate_tables_and_three_limits():
    cal = fit_replicate_calibration(LEVELS, AREAS)
    from analytical_lab import lod_loq_from_calibration

    limits = [
        lod_loq_from_calibration(cal.fit_all, "residual_sd"),
        lod_loq_from_calibration(cal.fit_all, "intercept_se"),
        lod_loq_from_curves(cal.fit_each),
    ]
    html = build_report(limits=limits, calibration=cal)
    assert "Replicate summary per level" in html
    assert "Separate curve per replicate series" in html
    assert "r squared on level means" in html
    assert html.count("SD of intercepts") >= 1


def test_cli_replicate_linearity(tmp_path):
    p = tmp_path / "lin.csv"
    p.write_text("conc,Area 1,Area 2,Area 3\n" + "\n".join(
        f"{c},{a[0]},{a[1]},{a[2]}" for c, a in zip(LEVELS, AREAS)) + "\n")
    out = tmp_path / "r.html"
    assert main(["report", "--linearity", str(p), "--out", str(out)]) == 0
    text = out.read_text(encoding="utf-8")
    assert "Replicate summary per level" in text
    assert "calibration curve" in text and "SD of intercepts" in text


def test_cli_linearity_needs_response_or_areas(tmp_path, capsys):
    p = tmp_path / "bad.csv"
    p.write_text("conc,foo\n1,2\n2,3\n3,4\n4,5\n5,6\n")
    assert main(["report", "--linearity", str(p), "--out", str(tmp_path / "o.html")]) == 2
    assert "area" in capsys.readouterr().err.lower()
