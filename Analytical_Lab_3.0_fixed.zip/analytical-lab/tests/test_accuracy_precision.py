import math

import numpy as np
import pytest

from analytical_lab import (
    assess_accuracy,
    intermediate_precision,
    percent_recovery,
    percent_rsd,
    repeatability,
)


def test_percent_recovery():
    assert np.allclose(percent_recovery([80, 100], [79.2, 101]), [99.0, 101.0])


def test_percent_recovery_rejects_nonpositive_added():
    with pytest.raises(ValueError):
        percent_recovery([0, 100], [1, 100])


def test_assess_accuracy_known_answer():
    res = assess_accuracy([80, 80, 100, 100], [80, 80, 100, 100], [79.2, 80.8, 101.0, 99.0])
    assert res.n == 4
    assert [lv.level for lv in res.levels] == [80.0, 100.0]
    for lv in res.levels:
        assert lv.mean_recovery == pytest.approx(100.0)
        assert lv.sd == pytest.approx(math.sqrt(2.0))
    assert res.overall_mean == pytest.approx(100.0)
    assert res.overall_ci[0] < 100.0 < res.overall_ci[1]


def test_assess_accuracy_single_replicate_gives_nan_not_crash():
    res = assess_accuracy([100], [10.0], [9.9])
    assert math.isnan(res.levels[0].sd)


def test_percent_rsd_known_answer():
    # sample SD of 10, 11, 12 is 1 and the mean is 11, so %RSD = 100 / 11
    assert percent_rsd([10, 11, 12]) == pytest.approx(100.0 / 11.0)


def test_repeatability():
    r = repeatability([100.0, 101.0, 99.0, 100.0, 100.0, 100.0])
    assert r.n == 6
    assert r.mean == pytest.approx(100.0)
    assert r.rsd == pytest.approx(r.sd)  # mean is 100 so %RSD == SD


def test_repeatability_needs_two_values():
    with pytest.raises(ValueError):
        repeatability([1.0])


def test_intermediate_precision_known_answer():
    # Group A = 10,11,12 ; group B = 20,21,22
    # MS_within = 1 ; MS_between = 150 ; n0 = 3 ; s_b^2 = 149/3 ; s_IP^2 = 1 + 149/3
    res = intermediate_precision([10, 11, 12, 20, 21, 22], ["A", "A", "A", "B", "B", "B"])
    assert res.ms_within == pytest.approx(1.0)
    assert res.ms_between == pytest.approx(150.0)
    assert res.s_repeatability == pytest.approx(1.0)
    assert res.s_between == pytest.approx(math.sqrt(149.0 / 3.0))
    assert res.s_intermediate == pytest.approx(math.sqrt(1.0 + 149.0 / 3.0))
    assert res.grand_mean == pytest.approx(16.0)


def test_intermediate_precision_no_group_effect_gives_zero_between():
    vals = [10.0, 12.0, 11.0, 10.0, 12.0, 11.0]
    res = intermediate_precision(vals, [1, 1, 1, 2, 2, 2])
    assert res.s_between == 0.0
    assert res.s_intermediate == pytest.approx(res.s_repeatability)


def test_intermediate_precision_unbalanced_design_runs():
    res = intermediate_precision([10, 11, 12, 13, 20, 21], ["a", "a", "a", "a", "b", "b"])
    assert res.n_groups == 2 and res.n_total == 6
    assert res.s_intermediate >= res.s_repeatability


def test_intermediate_precision_rejects_missing_group_label():
    with pytest.raises(ValueError, match="missing labels"):
        intermediate_precision([10, 11, 12, 20], ["a", "a", "a", float("nan")])


@pytest.mark.parametrize(
    "vals,groups",
    [
        ([1, 2, 3], ["a", "a", "a"]),       # one group
        ([1, 2], ["a", "b"]),               # no replicates
        ([1, 2, 3], ["a", "b"]),            # length mismatch
    ],
)
def test_intermediate_precision_invalid(vals, groups):
    with pytest.raises(ValueError):
        intermediate_precision(vals, groups)
