import pandas as pd
import pytest

from analytical_lab import summarize_robustness


def test_robustness_known_answer():
    data = pd.DataFrame({"flow": [1, 1, 2, 2], "response": [9, 11, 12, 14]})
    result = summarize_robustness(data, ["flow"])
    effect = result.effects[0]
    assert effect.mean_low == pytest.approx(10)
    assert effect.mean_high == pytest.approx(13)
    assert effect.effect == pytest.approx(3)
    assert effect.effect_percent_of_grand_mean == pytest.approx(3 / 11.5 * 100)


@pytest.mark.parametrize(
    "data,factors",
    [
        (pd.DataFrame({"response": [1, 2]}), ["missing"]),
        (pd.DataFrame({"x": [1, 1, 1, 1], "response": [1, 2, 3, 4]}), ["x"]),
        (pd.DataFrame({"x": [1, 1, 2, 2], "response": [1, 2, 3, float("nan")]}), ["x"]),
    ],
)
def test_robustness_rejects_invalid_inputs(data, factors):
    with pytest.raises(ValueError):
        summarize_robustness(data, factors)


def test_robustness_requires_two_replicates_at_each_setting():
    data = pd.DataFrame({"x": [1, 1, 2], "response": [1, 2, 3]})
    with pytest.raises(ValueError, match="at least 2 observations"):
        summarize_robustness(data, ["x"])
