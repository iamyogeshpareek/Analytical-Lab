# Analytical Lab — Analytical Procedure Workbench

Analytical Lab includes a standalone browser app and an optional Python desktop/command-line toolkit for selected analytical procedure calculations. It is designed for researchers and analysts working with numeric concentration and instrument-response data.

## Browser app

Open `Analytical Lab.html` from the repository root in a modern browser. Upload an Excel workbook or calibration CSV and follow the in-app Help for accepted column headings. The app can report calibration equations and plots, linearity, estimated LOD/LOQ, recovery, precision, and robustness when compatible tables are supplied. Multiple calibration curves are reported separately. Data are processed locally in the browser.

## Python desktop tool

The optional Python package is in the `analytical-lab` folder. On Windows, run `Open Analytical Lab data tool.ps1` from the repository root. It creates a local virtual environment, installs dependencies, and starts the desktop data-entry window. Python 3.9 or newer is required; internet access is needed during initial setup.

To generate a synthetic example report, run `Run Analytical Lab demo.ps1` from the repository root. For command-line use after installation, run `analytical-lab report --help`. The Python API package is imported as `analytical_lab`.

The `examples` directory contains synthetic input tables. They are illustrative and are not experimental evidence.

## Calculation scope and limitations

The tool provides calculations and optional criteria entered by the user. It does not select universal acceptance limits, decide whether a method is suitable, establish ICH compliance, or replace a validated system or approved protocol. Verify results, assumptions, mappings, units, and conclusions independently against applicable guidance and a suitable reference calculation.

## License

MIT License. See [LICENSE](analytical-lab/LICENSE).
